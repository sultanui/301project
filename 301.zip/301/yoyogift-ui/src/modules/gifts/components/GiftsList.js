import React from "react";
// import { render } from "react-dom";
import GiftCard from "../../common/components/GiftCard";

import {
  CellMeasurer,
  CellMeasurerCache,
  createMasonryCellPositioner,
  Masonry,
  AutoSizer,
  InfiniteLoader,
  WindowScroller
} from "react-virtualized";

const limit = 1020;
let fetchCount = 1;
// let imageId = 10;

//******************************* */

const CARD = {
  WIDTH: 250,
  HEIGHT: 250
};

class GiftsList extends React.Component {
  state = {
    columnCount: 0,
    items: this.props.giftCardsFiltered,
    currentIndex:0
  };

  _cache = new CellMeasurerCache({
    fixedHeight: true,
    fixedWidth: true,
    defaultHeight: CARD.HEIGHT
  });

  _config = {
    columnWidth: CARD.WIDTH,
    gutterSize: 10,
    overscanByPixels: CARD.HEIGHT
  };

  getPositionerConfig = width => {
    const { gutterSize } = this._config;
    const columnCount = this.getColumnCount(width);
    return {
      columnCount,
      columnWidth: CARD.WIDTH,
      spacer: gutterSize
    };
  };

  resetCellPositioner = width => {
    const config = this.getPositionerConfig(width);
    this._cellPositioner.reset(config);
  };

  getColumnCount = width => {
    const { columnWidth, gutterSize } = this._config;
    const columnCount = Math.floor(width / (columnWidth + gutterSize));
    this.setState({ columnCount });
    return columnCount;
  };

  initCellPositioner(width) {
    if (typeof this._cellPositioner === "undefined") {
      const config = this.getPositionerConfig(width);
      this._cellPositioner = createMasonryCellPositioner({
        cellMeasurerCache: this._cache,
        ...config
      });
    }
  }

  onResize = ({ width }) => {
    this.resetCellPositioner(width);
    this._masonry.recomputeCellPositions();
  };

  isRowLoaded = ({ index }) => {
    return this.props.giftCardsFiltered[index];
  };

  loadMoreRows = async () => {
    console.log("loadmore", fetchCount++);
    let { giftCardsFiltered } = this.props;
    if (giftCardsFiltered.length < limit) {
      const currentIndex = this.state.currentIndex + 10;
      this.props.fetchCardswithlimit(currentIndex, 10)
      this.setState({currentIndex})
    }
  };

  cellRenderer = config => {
    const { index, key, parent, style } = config;
    const giftCard = this.props.giftCardsFiltered[index];
    let content;
    content = giftCard ? (
      <div
        style={{
          width: "250px",
          height: "230px",
          display: "grid"
          // textAlign: "center",
          // backgroundColor: "#ccc",
          // margin: "20px",
        }}
      >
        <GiftCard giftCard={giftCard} userEmail={this.props.userDetails.email} />
      </div>
    ) : null;
    return (
      <CellMeasurer cache={this._cache} index={index} key={key} parent={parent}>
        <div
          style={{
            ...style,
            width: CARD.WIDTH,
            height: CARD.HEIGHT
          }}
        >
          {content}
        </div>
      </CellMeasurer>
    );
  };

  renderMasonry = (registerChild, onRowsRendered, height, scrollTop) => ({
    width
  }) => {
    this.initCellPositioner(width);
    const { giftCardsFiltered } = this.props;

    return (
      <Masonry
        cellCount={giftCardsFiltered.length}
        cellMeasurerCache={this._cache}
        cellPositioner={this._cellPositioner}
        cellRenderer={this.cellRenderer}
        autoHeight
        height={height}
        scrollTop={scrollTop}
        overscanByPixels={CARD.HEIGHT}
        ref={ref => (this._masonry = ref)}
        onCellsRendered={onRowsRendered}
        width={width}
      />
    );
  };

  render() {
    const { giftCardsFiltered } = this.props;
    if (!giftCardsFiltered) return null;

    return (
      <div>
        <InfiniteLoader
          isRowLoaded={this.isRowLoaded}
          loadMoreRows={this.loadMoreRows}
          rowCount={giftCardsFiltered.length < limit ? giftCardsFiltered.length + 1 : giftCardsFiltered.length}
        >
          {({ registerChild, onRowsRendered }) => (
            <WindowScroller overscanByPixels={CARD.HEIGHT}>
            {({ height, scrollTop }) => (
              <AutoSizer
                disableHeight
                onResize={this.onResize}
                height={height}
                scrollTop={scrollTop}
              >
                {this.renderMasonry(
                  registerChild,
                  onRowsRendered,
                  height,
                  scrollTop
                )}
              </AutoSizer>
            )}
          </WindowScroller>
          )}
        </InfiniteLoader>
      </div>
    );
  }
}

export default GiftsList;
