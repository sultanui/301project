export const apiURL = 'http://localhost:5000'
export const adminEmail = [
    "rsulthan.2009@gmail.com",
]